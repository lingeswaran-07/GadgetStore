import { useState } from "react";
import Gadgets from "./components/Gadgets";
import Header from "./components/Header";
import './App.css'
import Search from "./components/Search";
const App=()=>{
  const [CART,setCART]=useState([]);
  return(
    <>
             <Header CART={CART}/>
             <Search/>
           <Gadgets
            setCART={setCART}
            CART={CART}
           />
          
    </>
  )
};

export default App;