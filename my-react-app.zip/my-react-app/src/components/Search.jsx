import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import './Search.css'
const Search = () => {
  return (
    <div className='search'>
      <FontAwesomeIcon icon={faSearch} />&nbsp;
      <input type="text" placeholder="Search..." />
      <button type='submit'>search</button>
    
    </div>
  );
};

export default Search;
