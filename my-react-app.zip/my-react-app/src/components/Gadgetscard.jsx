import { useDispatch } from "react-redux";
import { incre } from "../Redux/Cartslice";
import { decrement, increment } from "../Redux/Counterslice";

const Gadgetscard=(props)=>{
    const dispatch=useDispatch();
    const add=()=>{
        dispatch(incre())
        

    }

    const increm=()=>{
        dispatch(increment())
    }

    const decrem=()=>{
        dispatch(decrement())
    }
    return (
        <>
          <div className="gadget-card">
            <img src={props.item.image}/>
            <p>{props.item.title}</p>
            <p>${props.item.price}</p>
            <p>{props.item.description}</p>
            <p>{props.item.category}</p>
            <button className="btn3" onClick={decrem}> -</button>&nbsp;
            <button className="btn2" onClick={add}> Add to cart</button>&nbsp;
           
            <button className="btn1" onClick={increm}> +</button>
          </div>
        </>
    )
};

export default Gadgetscard;
