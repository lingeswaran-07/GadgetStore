import { createSlice } from "@reduxjs/toolkit";



const Cartslice= createSlice({
    name:"carts",
    initialState:{
        CART:0
    },
    reducers:{
        incre:(state,action)=>{
            state.CART+=action.payload || 1;
        },
        

    }

});
export const {incre}=Cartslice.actions;
export default Cartslice.reducer;
