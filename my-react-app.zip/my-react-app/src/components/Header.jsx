import { useSelector } from "react-redux";

const Header=()=>{
    const CART=useSelector((state)=>state.carts.CART);
    const count=useSelector((state)=>state.counter.count)
    return ( 
    <>
    <nav className="head">
       <h1>SHOPIFY</h1>
       <ul>
        <li><a>HOME</a></li>
        <li><a>GADGETS</a></li>
        <span >CART:0{CART}</span>&nbsp;
        <span>COUNT:0{count}</span>
       </ul>
       </nav>

    </>

    )
};
export default Header;