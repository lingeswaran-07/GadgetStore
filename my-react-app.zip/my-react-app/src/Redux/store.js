import { configureStore } from '@reduxjs/toolkit';
import counterReducer from './Counterslice';
import cartsReducer from './Cartslice';

const store = configureStore({
  reducer: {
    counter: counterReducer,
    carts:cartsReducer
  },
});

export default store;
