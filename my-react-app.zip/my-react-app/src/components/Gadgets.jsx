import { Gadget } from "./Contents";
import Gadgetscard from "./Gadgetscard";

const Gadgets=({ CART, setCART})=>{

    return(
        <>
               
               <div className="gad-container">
                {Gadget.map((item)=>(
                    <Gadgetscard
                    key={item.id}
                    item={item}
                    CART={CART}
                    setCART={setCART}
                    />
                ))}
               </div>
        </>
    );
}

export default Gadgets;